From: Jay Fenton <jay@fentonia.com>
To: gridle@mbnet.fi
Date: 5.6.1999 2:11
Subject: Robby Roto ROM released for free non-commercial uses by author/owner

I used to write games for Bally/Midway in the 1970's and early
1980's. One of my less successful titles was Robby Roto.
My contract with Midway specified that after shipments dropped
below a certain level, that the rights to this game reverted to me.
Needless to say, this has happened.

I notice that Robby Roto is available on a few download sites for
MAME. I would like the world to know that as the legal owner,
the ROM images from Robby Roto are hearby declared free for
unlimited non-commercial duplication and play by MAME users.

-- Jay Fenton

